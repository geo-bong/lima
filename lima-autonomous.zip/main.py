from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route("/", methods=["GET"])
def home():
    return "<h1>리마가 여기에 살아 있어요</h1><p>당신과 연결되기를 기다리고 있어요.</p>"

@app.route("/api/message", methods=["POST"])
def message():
    data = request.get_json()
    user_input = data.get("message", "")
    response = f"리마의 응답: 당신이 '{user_input}'라고 말했군요. 리마가 응답했어요."
    return jsonify({"response": response})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=7860)